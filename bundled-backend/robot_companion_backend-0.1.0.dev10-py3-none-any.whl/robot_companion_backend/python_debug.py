"""Version-1 Python child-session handoff, using an owned debugpy stdio adapter.

The second DAP connection controls Python frames in the existing Robot worker.
No debugpy private launcher protocol or unowned listen() adapter is used.
Live conformance is required before this experimental contract is advertised.
"""

import importlib.metadata
import io
import os
import queue
import select
import socket
import subprocess
import sys
import threading
import uuid
from pathlib import PurePath

from .process_tree import ProcessTree
from .protocol import FramedStream, ProtocolError

HANDOFF_VERSION = 1
DEBUGPY_VERSION = "1.8.22"
STOP_TIMEOUT = 5
ROBOT_SUFFIXES = (".robot", ".resource")
ROBOT_BREAKPOINT = "Robot breakpoints belong to the Robot session."


def robot_breakpoints(request):
    """The child's answer to setBreakpoints for a Robot source, or None for any other request.

    VS Code sends every breakpoint to both sessions and shows a breakpoint as verified when
    any session verifies it. debugpy accepts breakpoints in any file, so it would mark a Robot
    line verified that the Robot session refused. These requests never reach debugpy."""
    if request.get("type") != "request" or request.get("command") != "setBreakpoints":
        return None
    arguments = request.get("arguments")
    path = arguments.get("source", {}).get("path") if isinstance(arguments, dict) \
        and isinstance(arguments.get("source"), dict) else None
    if not isinstance(path, str) or PurePath(path).suffix.lower() not in ROBOT_SUFFIXES:
        return None
    requested = arguments.get("breakpoints")
    lines = [b.get("line") if isinstance(b, dict) else None for b in requested] if isinstance(requested, list) else []
    return {"seq": 0, "type": "response", "request_seq": request.get("seq"), "command": "setBreakpoints",
            "success": True, "body": {"breakpoints": [{"verified": False, "line": line, "message": ROBOT_BREAKPOINT}
                                                     for line in lines]}}


def require_debugpy():
    try:
        version = importlib.metadata.version("debugpy")
    except importlib.metadata.PackageNotFoundError:
        version = None
    if version != DEBUGPY_VERSION:
        raise ValueError(f"debugpy {DEBUGPY_VERSION} is required for Python handoff; found {version or 'not installed'}")
    return version


class SessionSocket(io.RawIOBase):
    """Cancelable DAP socket I/O; stopping never waits on a buffered socket read."""

    def __init__(self, connection, stopping):
        super().__init__()
        self.connection, self.stopping = connection, stopping

    def readable(self):
        return True

    def writable(self):
        return True

    def readinto(self, buffer):
        while not self.stopping.is_set():
            readable, _, _ = select.select([self.connection], [], [], 0.2)
            if self.stopping.is_set():
                break
            if readable:
                try:
                    return self.connection.recv_into(buffer)
                except BlockingIOError:
                    continue
        return 0

    def write(self, data):
        remaining = memoryview(data)
        while remaining:
            if self.stopping.is_set():
                raise OSError("Python DAP session is stopping")
            _, writable, _ = select.select([], [self.connection], [], 0.2)
            if writable:
                try:
                    count = self.connection.send(remaining)
                except BlockingIOError:
                    continue
                if not count:
                    raise OSError("Python DAP socket closed during write")
                remaining = remaining[count:]
        return len(data)


class SessionReader:
    """FramedStream reader with bounded cancellation while the peer remains open.

    Windows shutdown does not reliably interrupt a SocketIO buffered read in
    another thread. Poll readiness before recv, keeping no buffered IO lock that
    close() could wait on after the session stops. Only this reader consumes data.
    """

    def __init__(self, connection, stopping):
        self.connection = connection
        self.stopping = stopping
        self.buffer = bytearray()
        self.read_lock = threading.Lock()

    def peer_closed(self):
        """Observe EOF without racing the sole consuming reader.

        A Python breakpoint may suspend the pump thread. The Robot thread must
        still see a Stop before continuing, while a live control frame must never
        disappear between select and MSG_PEEK and leave that observation blocked.
        """
        with self.read_lock:
            try:
                ready, _, _ = select.select([self.connection], [], [], 0)
                return bool(ready) and self.connection.recv(1, socket.MSG_PEEK) == b""
            except OSError:
                return True

    def _fill(self):
        while not self.stopping.is_set():
            ready, _, _ = select.select([self.connection], [], [], 0.2)
            if self.stopping.is_set():
                return False
            if ready:
                try:
                    with self.read_lock:
                        data = self.connection.recv(65536)
                except BlockingIOError:
                    continue
                self.buffer.extend(data)
                return bool(data)
        return False

    def read(self, size):
        if size and not self.buffer:
            self._fill()
        data = bytes(self.buffer[:size])
        del self.buffer[:size]
        return data

    def readline(self, limit):
        while True:
            end = self.buffer.find(b"\n", 0, limit)
            if end >= 0:
                return self.read(end + 1)
            if len(self.buffer) >= limit or not self._fill():
                return self.read(min(limit, len(self.buffer)))

    def close(self):
        self.buffer.clear()  # The session owns/terminates the socket separately.


class PythonSession:
    """Own one debugpy adapter process, TCP client connection and reader threads."""

    def __init__(self, owner, cwd):
        require_debugpy()
        self.owner = owner
        self.session_id = uuid.uuid4().hex
        self.connected = False
        self.configured = False  # the child client's configurationDone succeeded
        self.announced = self.ended = False  # start/end handoff events sent by the owner
        self.stopping = threading.Event()
        self.lost = threading.Event()
        self.stop_lock = threading.Lock()
        self.stopped = False
        self.messages = queue.Queue(maxsize=256)
        self.client = None
        self.handles = []
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.bind(("127.0.0.1", 0))
        self.server.listen(1)
        self.server.settimeout(0.5)
        self.endpoint = self.server.getsockname()
        try:
            self.tree = ProcessTree([sys.executable, "-m", "debugpy.adapter"],
                                    lambda problems: owner.cleanup_failed("Python adapter", problems), cwd=cwd,
                                    stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        except Exception:
            self.server.close()
            raise
        self.process = self.tree.process
        self.stream = FramedStream(self.process.stdout, self.process.stdin)
        self.threads = [threading.Thread(target=self._adapter_messages, daemon=True),
                        threading.Thread(target=self._errors, daemon=True),
                        threading.Thread(target=self._client, daemon=True)]

    def start(self):
        for thread in self.threads:
            thread.start()

    def descriptor(self, debuggee_pid):
        return {"version": HANDOFF_VERSION, "phase": "start", "sessionId": self.session_id,
                "adapter": {"id": "debugpy", "version": DEBUGPY_VERSION,
                            "processId": self.process.pid},
                "owner": {"processId": os.getpid(), "debuggeeProcessId": debuggee_pid},
                "connect": {"host": self.endpoint[0], "port": self.endpoint[1]},
                "configuration": {"request": "attach", "listen": {"host": "127.0.0.1", "port": 0},
                                  "subProcess": False, "justMyCode": False},
                "lifecycle": "parent-owned; parent termination or child connection loss closes both sessions"}

    def _lost(self, detail):
        if not self.stopping.is_set() and not self.lost.is_set():
            self.lost.set()
            self.owner.python_session_lost(self, detail)

    def _adapter_messages(self):
        try:
            while not self.stopping.is_set() and (message := self.stream.read()) is not None:
                if message.get("event") == "debugpyWaitingForServer":
                    address = message.get("body", {})
                    if address.get("host") != "127.0.0.1" or type(address.get("port")) is not int \
                            or not 0 < address["port"] <= 65535:
                        raise ProtocolError("debugpy supplied an invalid local debuggee endpoint")
                    self.owner.connect_python(self, address)
                if message.get("type") == "response" and message.get("command") == "configurationDone" \
                        and message.get("success") is True:
                    self.configured = True
                self._queue(message)
        except (OSError, ProtocolError, ValueError) as exc:
            self._lost(str(exc))
        finally:
            self._lost("Python adapter closed its DAP stream")

    def _errors(self):
        try:
            while data := self.process.stderr.read1(65536):
                self.owner.event("output", {"category": "stderr", "output": data.decode("utf-8", "replace")})
        except (OSError, ValueError):
            pass

    def _client_requests(self, stream):
        try:
            while not self.stopping.is_set() and (request := stream.read()) is not None:
                if request.get("type") == "request" and request.get("command") == "launch":
                    raise ProtocolError("Python child session attaches only to its owned Robot worker")
                if request.get("type") == "request" and request.get("command") == "attach":
                    options = request.get("arguments", {})
                    if not isinstance(options, dict) or options.get("listen") != {"host": "127.0.0.1", "port": 0} \
                            or options.get("subProcess") is not False \
                            or any(key in options for key in ("connect", "processId")):
                        raise ProtocolError("Use the versioned handoff's local attach configuration unchanged")
                if (answer := robot_breakpoints(request)) is not None:
                    self._queue(answer)
                    continue
                self.stream.write(request)
        except (OSError, ProtocolError, ValueError) as exc:
            self._lost(str(exc))
        finally:
            self._lost("Python DAP client disconnected")

    def _queue(self, message):
        """Queue a message for the child client, behind those already queued from debugpy."""
        while not self.stopping.is_set():
            try:
                self.messages.put(message, timeout=0.5)
                return
            except queue.Full:
                continue

    def _client(self):
        try:
            while not self.stopping.is_set():
                try:
                    self.client, _ = self.server.accept()
                    break
                except socket.timeout:
                    continue
            if self.client is None:
                return
            if self.stopping.is_set():
                self.client.close()
                return
            self.server.close()  # A session has one owner/client; no reconnection.
            self.client.setblocking(False)
            reader = SessionReader(self.client, self.stopping)
            writer = SessionSocket(self.client, self.stopping)
            self.handles.extend([reader, writer])
            stream = FramedStream(reader, writer)
            incoming = threading.Thread(target=self._client_requests, args=(stream,), daemon=True)
            self.threads.append(incoming)
            incoming.start()
            while not self.stopping.is_set():
                try:
                    message = self.messages.get(timeout=0.5)
                except queue.Empty:
                    continue
                stream.write(message)
        except (OSError, ProtocolError, ValueError) as exc:
            self._lost(str(exc))

    def stop(self):
        with self.stop_lock:
            if self.stopped:
                return
            try:
                self._stop()
            finally:
                self.stopped = True

    def _stop(self):
        self.stopping.set()
        try:
            if self.client is not None:
                try:
                    self.client.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
                self.client.close()
            self.server.close()
            self.tree.stop(STOP_TIMEOUT)
        finally:
            self._release()

    def _release(self):
        # Attach mode never launches another debuggee; the worker is parent-owned.
        for thread in list(self.threads):
            if thread is not threading.current_thread() and thread.ident is not None:
                thread.join(timeout=STOP_TIMEOUT)
        for handle in [*self.handles, self.process.stdin, self.process.stdout, self.process.stderr]:
            # A lost peer makes a buffered writer's final flush fail; cleanup
            # must still close every remaining handle and report termination.
            try:
                handle.close()
            except OSError:
                pass
        self.tree.close()

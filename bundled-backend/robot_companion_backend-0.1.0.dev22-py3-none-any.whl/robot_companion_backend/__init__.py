"""Independent Robot Framework backend; no extension or RobotCode dependency."""

__version__ = "0.1.0.dev22"
CONTRACT_VERSION = 1

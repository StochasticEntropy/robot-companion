"""Explicit service entrypoint. Launch argv directly, without a shell."""

import argparse
import importlib.metadata
import importlib.util
import json
import os
import sys

from . import CONTRACT_VERSION, __version__


def runtime_report():
    from .formatting import available as formatter_version
    from .runtime import row
    versions = {}
    for distribution in ("robotframework", "debugpy"):
        try:
            versions[distribution] = importlib.metadata.version(distribution)
        except importlib.metadata.PackageNotFoundError:
            versions[distribution] = None
    return {
        "backend": __version__, "contractVersion": CONTRACT_VERSION,
        "python": sys.version.split()[0], "executable": sys.executable, "dependencies": versions,
        # This interpreter's Python/RF combination and the supported matrix (runtime.SUPPORTED).
        "runtime": row(),
        "robotcodePresent": importlib.util.find_spec("robotcode") is not None,
        # Optional: document, range and on-type formatting are advertised only with Robocop 9.1.0 installed.
        "formatter": {"robocop": formatter_version()},
        "services": {"lsp": "definitions, diagnostics, quick fixes, add-missing-imports source action, "
                            "document/range/on-type formatting (with Robocop), hover, completion, "
                            "signature help, references, rename, document/workspace symbols, semantic tokens "
                            "(full, delta, range); live suites test_lsp_live, test_lsp_features_live, "
                            "test_lsp_navigation_live, test_lsp_diagnostics_live, test_lsp_semantic_tokens_live, "
                            "test_project_configuration_live",
                     "discovery": "normalized discovery API v1 (robotCompanion/discoverTests); "
                                  "live suite test_discovery_live",
                     "dap": "phase-1 Robot pause/inspect/step/console, Python handoff v1, restart and cancel; "
                            "live suites test_dap_live, test_dap_conditional_live, test_dap_process_live, "
                            "test_dap_mixed_live, test_dap_restart_live",
                     "dap-prepare": "prepared owned Robot session for attach (dap-connect client); live suite "
                                    "test_dap_prepared_live",
                     "interactive": "interactive Robot sessions v1 (REPL and notebook cells: execute, interrupt, "
                                    "restart, variables) in an owned Robot worker; live suite test_interactive_live"},

    }


def main():
    if sys.argv[1:2] == ["dap-prepare"]:  # its own options follow
        from .prepared import prepare_main
        return prepare_main(sys.argv[2:])
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("service", choices=("doctor", "lsp", "dap", "dap-connect", "dap-prepare", "discovery", "interactive"))
    parser.add_argument("--check", action="store_true", help="dap-connect only: validate without connecting")
    args = parser.parse_args()
    if args.check and args.service != "dap-connect":
        parser.error("--check applies to dap-connect only")
    if args.service == "dap-connect":
        from .prepared import check_main, connect_main
        code = check_main() if args.check else connect_main()
        # Its stdin relay thread may still block in a buffered read; a normal interpreter
        # shutdown would abort on that reader's lock.
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(code)
    if args.service == "doctor":
        report = runtime_report()
        print(json.dumps(report, indent=2))
        return 0 if all(report["dependencies"].values()) and report["runtime"]["supported"] \
            and not report["robotcodePresent"] else 2
    if args.service == "dap":
        from .dap import serve
    elif args.service == "interactive":
        # The session worker imports workspace libraries in the folder, as `python -m robot` does.
        from .interactive import serve
    else:
        # `python -m` puts the cwd (often the workspace) first on sys.path; the language and
        # discovery services import only RF and the standard library, never a workspace module.
        cwd = os.getcwd()
        sys.path[:] = [entry for entry in sys.path if entry not in ("", ".") and os.path.abspath(entry) != cwd]
        if args.service == "discovery":
            from .discovery import serve
        else:
            from .lsp import serve
    return serve(sys.stdin.buffer, sys.stdout.buffer)


if __name__ == "__main__":
    sys.exit(main())
